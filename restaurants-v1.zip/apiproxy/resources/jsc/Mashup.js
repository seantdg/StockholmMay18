var originalPayload = JSON.parse(context.getVariable("response.content"));
var reviewPayload = JSON.parse(context.getVariable("calloutResponse.content"));

originalPayload.restaurants.forEach(function(restaurant) {
    restaurant.comments = [];
    reviewPayload.reviews.forEach(function(review) {
        if(restaurant.name === review.restaurant) {
            restaurant.comments.push(review.comment);
        }
    });
});

context.setVariable("response.content", JSON.stringify(originalPayload));